# Object Relationship Report — Phase 3 Constitutional Relationship Model

> Catalog of the immutable object relationships defined by the Phase 3 relationship layer, with each model's object kinds, composed-of relationship kinds, and cross-references into the Phase 1 registries and Phase 2 specifications. Authority: ADR-001, ADR-002, `constitutional-enforcement-architecture.md`, `constitutional-object-model.md` (§1, §2.1–§2.3), `architecture/registry/phase1-completion-report.md`, `architecture/registry/phase2-completion-report.md`.

## 1. Relationship-kind vocabulary (26 kinds)

| Kind | Valid from → to | Meaning | Source |
|---|---|---|---|
| realizes | Principle → Invariant | A principle is realized by one or more invariants (e.g., P3 realizes I5). | object-model §2.1 |
| derives-from | Invariant → Principle | An invariant is a checkable derivative of a principle. | object-model §2.1 |
| constrained-by | Rule → Constraint | Every rule has at least one operational predicate (constraint). | object-model §2.1 |
| owns | Rule/Evidence/Aggregate/Term/Registry/Specification → Ownership | Exactly one owning body per object/artifact (P2, I4, G5). | object-model §2.1/§2.3 |
| is-owned-by | Ownership → all | Inverse of owns. | object-model §2.3 |
| belongs-to | Rule/Constraint/Evidence/Verification/Gate → Baseline | Active rules compose Baseline v2. | object-model §2.1 |
| supersedes | changeable → changeable | Via ADR; the old object is deprecated, the new one traces back (T3). | object-model §2.1 |
| is-superseded-by | changeable → changeable | Inverse of supersedes. | object-model §2.1 |
| examines | Constraint → Evidence | The predicate operates on the evidence artifact(s). | object-model §2.2 |
| is-examined-by | Evidence → Constraint | Evidence is inert without a constraint. | object-model §2.2 |
| evaluates | Verification → Evidence | Verification evaluates evidence against the constraint. | object-model §2.2 |
| is-evaluated-by | Evidence → Verification | Inverse of evaluates. | object-model §2.2 |
| requires | Gate → Verification | A gate requires a verification result before an action proceeds. | object-model §2.2 |
| is-required-by | Verification → Gate | Inverse of requires. | object-model §2.2 |
| produces | Verification/Gate → Decision | Verification produces a binary result; a gate produces a ruling. | object-model §2.2 |
| records | Decision → … | A decision records an outcome with authority. | object-model §2.2 |
| grants | Decision → Exception | A decision grants a sanctioned deviation. | object-model §2.2 |
| suspends | Exception → Rule | An exception suspends the affected rule for its duration. | object-model §2.2 |
| cites | object → Document | A decision or object cites its authority. | object-model §2.3 |
| proposes | ADR → changeable | An ADR proposes a change to a constitutional object. | object-model §2.3 |
| amends | ADR → changeable | An ADR amends a constitutional object. | object-model §2.3 |
| replaces | ADR → changeable | An ADR replaces a constitutional object. | object-model §2.3 |
| retires | ADR → changeable | An ADR retires a constitutional object. | object-model §2.3 |
| attaches-to | … → Baseline | Cross-cutting link binding an object to the baseline. | object-model §2.3 |
| traverses | Traceability → chain | Traceability traverses the backward chain decision → evidence → constraint → rule. | object-model §2.3 |
| extends | Specification → Registry | A spec kind governs the records of its Phase 1 registry (Phase 2 layer link). | Phase 2 / §2 |

## 2. Model catalog (10 models)

| # | Model | Object kinds | Composed of kinds | Purpose (abridged) |
|---|---|---|---|---|
| 1 | MODEL-IDENTITY | Rule, Principle, Invariant, ADR, Constraint, Evidence, Verification, Gate, Decision, Exception, Lifecycle, Ownership, Traceability, Baseline, Registry, Specification, State, Aggregate, Term | owns, cites, extends, supersedes | Strongly typed constitutional identity: every object kind anchored to the R1..R11/spec layer via 12 id rules |
| 2 | MODEL-LINKING | Registry, Specification, Baseline | extends, attaches-to, traverses | Layer pipeline Registry → Specification → Relationship Model → Future Enforcement Engine with no Registry → Runtime edge |
| 3 | MODEL-DEPENDENCY-GRAPH | Rule, Constraint, Evidence, Verification, Gate, Decision | constrained-by, examines, evaluates, requires, produces | Structural dependency graph of the enforcement chain; execution order governed by the graph (P4/I6) |
| 4 | MODEL-TRACEABILITY | Decision, Evidence, Constraint, Rule, Traceability | records, produces, traverses, cites, evaluates, examines, constrained-by | Backward traceability graph decision → evidence → constraint → rule (T3/G3/EC8) |
| 5 | MODEL-AUTHORITY-RESOLUTION | Rule, Decision, Exception, Ownership, Baseline | owns, records, cites | Decision map turning each domain owner D1..D8 into authority body + documents + basis |
| 6 | MODEL-EVIDENCE-OWNERSHIP | Evidence, Ownership, Aggregate, Baseline | owns, is-owned-by, attaches-to | Single-owner structure for every evidence artifact (P2/I4/G5), enforced by the evidence domain (D3) |
| 7 | MODEL-VERIFICATION-DEPENDENCY | Verification, Constraint, Evidence, Decision, Gate | evaluates, is-evaluated-by, examines, produces, is-required-by | Verification depends on its constraint and the evidence examined; D4 stays structurally independent |
| 8 | MODEL-GATE-DEPENDENCY | Gate, Verification, Decision, Rule | requires, is-required-by, produces | Gate requires verification, halts on failure/non-execution, produces a ruling; no gate on a breach (GD-2) |
| 9 | MODEL-DECISION-PROVENANCE | Decision, Verification, Gate, Evidence, Constraint, Rule, Traceability, Lifecycle | records, produces, traverses, cites, attaches-to | Provenance record every decision must carry: source, authority, record date, backward trace chain |
| 10 | MODEL-EXCEPTION-LINKAGE | Exception, Decision, Rule, Lifecycle, Baseline | grants, suspends, attaches-to, records | Exception granted by a decision, suspends a rule, carries authority/scope/expiry |

## 3. Cross-references into Phase 1 registries and Phase 2 specifications

| Model | Registry reference (Phase 1) | Specification reference (Phase 2) |
|---|---|---|
| MODEL-IDENTITY | R1 (43 elements), R2..R11 anchors | 6 spec kinds (SPEC-CONSTRAINT … SPEC-EXCEPTION) |
| MODEL-LINKING | R1..R11 (as `Registry` layer) | extends targets per spec kind |
| MODEL-DEPENDENCY-GRAPH | R1..R6 (chain anchors) | SPEC-CONSTRAINT/…/SPEC-DECISION (chain kinds) |
| MODEL-TRACEABILITY | R1, R2, R3, R6 (backward anchors) | SPEC-DECISION (tracesTo shape) |
| MODEL-AUTHORITY-RESOLUTION | D1..D8 domain owners (`registry.ts`) | each spec kind's owner field |
| MODEL-EVIDENCE-OWNERSHIP | R3 (7 artifact types, 13 present sources); R10 (Ownership Registry) | SPEC-EVIDENCE (owningBody field) |
| MODEL-VERIFICATION-DEPENDENCY | R4 (EC1..EC10, all NotRegistered; +I11, G11 outside set) | SPEC-VERIFICATION (inputs/outputs shape) |
| MODEL-GATE-DEPENDENCY | R5 (GATE-01..05, 0 assignments) | SPEC-GATE (requiredVerification/haltOn shape) |
| MODEL-DECISION-PROVENANCE | R6 (0 decisions); R7 (Execution Registry) | SPEC-DECISION (authority/tracesTo shape) |
| MODEL-EXCEPTION-LINKAGE | R9 (1 precedent, I11 Unrecorded) | SPEC-EXCEPTION (scope/expiry/status shape) |

## 4. Baseline state carried (unchanged) by the models

| Baseline | Phase 0/1 value | Phase 3 contribution |
|---|---|---|
| Constraints | 12 present / 31 gap | chain shape, `constrained-by` edge |
| Evidence | 7 artifact types; 13 present / 30 gap | single-owner rules over R3 artifacts |
| Verification | EC1..EC10, 7 Ready / 3 NeedsExtension, all NotRegistered | dependency structure; no procedure run |
| Gates | 5 gates, 0 element bindings, empty requiredVerification | dependency structure; no gate executed |
| Decisions | 0 recorded | provenance shape; no decision recorded |
| Exceptions | 1 precedent, Unrecorded (I11) | linkage structure; no exception granted |
