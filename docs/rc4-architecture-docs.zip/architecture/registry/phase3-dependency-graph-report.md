# Dependency Graph Report — Phase 3 Constitutional Relationship Model

> Structural report of the constitutional dependency graph defined by the Phase 3 relationship layer: the enforcement chain, its edge kinds, the layer pipeline, and the backward traceability chain. Graph **shape only** — no node is bound and no chain is instantiated; per-rule link presence stays at its Phase 0/1 baseline. Authority: ADR-002 (P4/I6), `constitutional-enforcement-architecture.md` (§2/§3/§4), `constitutional-object-model.md` (§4), `architecture/registry/phase1-completion-report.md`, `architecture/registry/phase2-completion-report.md`.

## 1. Enforcement chain (MODEL-DEPENDENCY-GRAPH)

```
   R1         R2          R3          R4         R5        R6
  Rule ──► Constraint ──► Evidence ──► Verification ──► Gate ──► Decision
              │             │             │              │          │
              │ constrained-│ examines     │ evaluates     │ requires │ produces
              │ by          │              │               │          │
              └─────────────┴──────────────┴───────────────┴──────────┘
```

| Position | Kind | Registry anchor | Incoming edge (kind) |
|---|---|---|---|
| 1 | Rule | R1 | — (chain head; constitutional source P/I/G/EC) |
| 2 | Constraint | R2 | constrained-by (from Rule) |
| 3 | Evidence | R3 | examines (from Constraint) |
| 4 | Verification | R4 | requires (from Gate, inverse) / evaluates (forward) |
| 5 | Gate | R5 | produces (from Verification) |
| 6 | Decision | R6 | produces (from Verification and Gate) |

Edge kinds composing the dependency graph: `constrained-by`, `examines`, `evaluates`, `requires`, `produces` (DEPENDENCY_EDGE_KINDS).

## 2. Layer pipeline (MODEL-LINKING)

```
 Registry ──extends──► Specification ──attaches-to──► Relationship Model ──traverses──► Future Enforcement Engine
   (R1..R11)            (SPEC-CONSTRAINT …              (10 models)                       (not implemented)
                        SPEC-EXCEPTION)
```

- The three edges are the only inter-layer paths.
- **No direct Registry → Runtime connection is permitted** (`LAYER_ARCHITECTURE_RULE`; extends `RUNTIME_ENFORCEMENT_PROHIBITED`, `SPECIFICATIONS_RUNTIME_PROHIBITED`, `RELATIONSHIPS_RUNTIME_PROHIBITED`).
- The future engine consumes the relationship model, never the registries directly.

## 3. Backward traceability chain (MODEL-TRACEABILITY)

```
 Decision ──records/produces──► Evidence ──examines──► Constraint ──constrained-by──► Rule
    R6                            R3                      R2                          R1
```

Direction is backward (T3/G3/EC8): every decision must trace decision → evidence → constraint → rule. The chain is the structural contract the future engine audits recorded provenance against.

## 4. Chain-link models

| Model | Depends on | Contributes |
|---|---|---|
| MODEL-EVIDENCE-OWNERSHIP | R3 artifacts; R10 Ownership Registry | single-owner `owns` edges per artifact (P2/I4/G5) |
| MODEL-VERIFICATION-DEPENDENCY | R4 EC procedures; constraints (R2); evidence (R3) | `evaluates`/`examines` edges + D4 independence invariant |
| MODEL-GATE-DEPENDENCY | R5 gates; R4 verifications | `requires`/`produces` edges + halt-on-failure (GD-3), no gate on a breach (GD-2) |
| MODEL-DECISION-PROVENANCE | R6; R7 execution records | `records`/`traverses` edge + backward provenance shape (DP-1..5) |
| MODEL-EXCEPTION-LINKAGE | R9 precedent; R6 decisions | `grants`/`suspends` edge + expiring exception shape (EL-1..5) |

## 5. Graph instantiation state (unchanged)

| Link | Baseline | Phase 3 status |
|---|---|---|
| constraints bound to rules | 12 / 43 | shape defined; no binding |
| evidence present | 13 / 43 (7 artifact types) | shape defined; no new artifact |
| verification registered | 10 / 43 (all NotRegistered; +I11, G11 ready outside set) | shape defined; no procedure run |
| gates bound | 0 / 43 (5 gates, 0 element assignments) | shape defined; no gate executed |
| decisions recorded | 0 / 43 | shape defined; no decision recorded |
| exceptions recorded | 1 precedent, Unrecorded | shape defined; no exception granted |

The dependency graph is a **shape**, not a state: it defines how the future engine will traverse links, while every link remains at its Phase 0/1 baseline. No runtime behavior, no API, no schema, no seed, no database change was made by Phase 3.
